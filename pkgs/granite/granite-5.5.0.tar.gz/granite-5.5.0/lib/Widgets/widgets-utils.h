#include <glib.h>
#include <gtk/gtk.h>
#include <granite.h>

void    granite_widgets_show_about_dialog (GtkWindow   *parent,
                                           const gchar *first_property_name,
                                           ...);