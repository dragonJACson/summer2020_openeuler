xfce-polkit
===========

A simple PolicyKit authentication agent for XFCE
