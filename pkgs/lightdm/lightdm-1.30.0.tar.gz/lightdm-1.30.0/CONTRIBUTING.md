We welcome improvements and bug fixes to LightDM. All changes should be proposed as [pull requests](https://github.com/CanonicalLtd/lightdm/pulls).

Contributors are required to have signed the [Canonical contributor licence agreement](http://www.ubuntu.com/legal/contributors).

Substantial changes must have associated regression tests. If you are having trouble making a suitable test please propose your change anyway and we'll try and help you write a test or write a test if necessary.
