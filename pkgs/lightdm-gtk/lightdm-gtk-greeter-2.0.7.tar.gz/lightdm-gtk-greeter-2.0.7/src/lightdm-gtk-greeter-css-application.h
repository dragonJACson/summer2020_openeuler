/* automatically generated from lightdm-gtk-greeter-application.css */
#ifdef __SUNPRO_C
#pragma align 4 (lightdm_gtk_greeter_css_application)
#endif
#ifdef __GNUC__
static const char lightdm_gtk_greeter_css_application[] __attribute__ ((__aligned__ (4))) =
#else
static const char lightdm_gtk_greeter_css_application[] =
#endif
{
  "*\n{\n  -GtkWidget-window-dragging: false;\n}\n"
};

static const unsigned lightdm_gtk_greeter_css_application_length = 43u;

