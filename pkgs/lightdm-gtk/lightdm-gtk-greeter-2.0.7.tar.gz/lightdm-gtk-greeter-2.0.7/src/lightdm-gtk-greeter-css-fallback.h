/* automatically generated from lightdm-gtk-greeter-fallback.css */
#ifdef __SUNPRO_C
#pragma align 4 (lightdm_gtk_greeter_css_fallback)
#endif
#ifdef __GNUC__
static const char lightdm_gtk_greeter_css_fallback[] __attribute__ ((__aligned__ (4))) =
#else
static const char lightdm_gtk_greeter_css_fallback[] =
#endif
{
  "#layout_menuitem>GtkLabel\n{\n    border: 1px solid alpha(@menu_fg_colo"
  "r, 0.8);\n    border-radius: 0.5em;\n    padding: 0px 0.25em;\n    back"
  "ground: alpha(@menu_fg_color, 0.2);\n}\n\n#layout_menuitem\n{\n    padd"
  "ing: 1px;\n}\n\n/* Make sure the GtkSeparatorMenuItems don\'t alter the"
  " overall panel/menubar background */\n#panel_window menubar > separator"
  " { background: transparent; }\n/* Workaround for Adwaita - and other th"
  "emes - setting a smaller font for the keycap window */\n#login_window.k"
  "eycap, #power_window.keycap { font-size: initial; }\n"
};

static const unsigned lightdm_gtk_greeter_css_fallback_length = 532u;

