Gtk im module for fcitx5 and glib based dbus client library
==========================================
[![Jenkins Build Status](https://img.shields.io/jenkins/s/https/jenkins.fcitx-im.org/job/fcitx5-gtk.svg)](https://jenkins.fcitx-im.org/job/fcitx5-gtk/)

[![Coverity Scan Status](https://img.shields.io/coverity/scan/12702.svg)](https://scan.coverity.com/projects/fcitx-fcitx5-gtk)
